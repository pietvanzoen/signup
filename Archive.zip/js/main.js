$(function() {
	
	$('button[data-loading-text]').click(function () {
	    $(this).button('loading');
	});

});
